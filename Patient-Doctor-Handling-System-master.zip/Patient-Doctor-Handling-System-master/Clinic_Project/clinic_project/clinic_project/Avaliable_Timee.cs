﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clinic_project
{
    public partial class Avaliable_Timee : Form
    {
        
        public Avaliable_Timee()
        {
            InitializeComponent();

           
        }

        private void Avaliable_Timee_Load(object sender, EventArgs e)
        {

        }
    }
}
