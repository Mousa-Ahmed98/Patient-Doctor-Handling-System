﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clinic_project
{
    class Doctor
    {
        private int  idDoctor_c;
        private string fname_c;
        private string lanem_c;
        private string phone_c;
        private string address_c;
        private string day_c;
        private int h1_c;
        private int h2_c;
        private int h3_c;
        private int h4_c;
        private int h5_c;
        private int h6_c;
        private int h7_c;
        private int h8_c; 


        public Doctor()
        {

        }

        

        





    }
}
