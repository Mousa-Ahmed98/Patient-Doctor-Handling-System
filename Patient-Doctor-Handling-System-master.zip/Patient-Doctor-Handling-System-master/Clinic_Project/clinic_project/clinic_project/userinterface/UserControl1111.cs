﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clinic_project.userinterface
{
    public partial class UserControl1111 : UserControl
    {
        public UserControl1111()
        {
            InitializeComponent();
        }
    }
}
