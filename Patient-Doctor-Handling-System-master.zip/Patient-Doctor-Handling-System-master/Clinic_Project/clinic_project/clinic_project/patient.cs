﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clinic_project
{
    class patient
    {
        private int idpatient;
        private string fname_c;
        private string lanem_c;
        private string phone_c;
        private string type_of_disease_c;
        private int pat_Hour_c;
       


        public patient()
        {

        }





    }
}
